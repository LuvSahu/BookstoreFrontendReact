import React, { useState } from "react";
import { BrowserRouter as Router, Routes,Route } from "react-router-dom";
import Cart from "../pages/cart/cart";
import Dashboard from "../pages/dashboard/dashboard";
import Lander from "../pages/lander/lander";
import Order from "../pages/orderplaced/order";

const BookRouter = () => {
    return (
        <div>
            <Router>
                <Routes>
                    <Route path="/" element={<Lander/>}/>
                    <Route path="/dashboard" element={<Dashboard/>}/>
                    <Route path="/cart" element={<Cart/>}/>
                    {/* <Route path="/order" element={<Order/>}/> */}


                </Routes>
            </Router>
        </div>

    )

}

export default BookRouter