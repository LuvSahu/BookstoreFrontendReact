import React from "react";
import Button from '@mui/material/Button';
import './orderplaced.css'
import Header from "../header/header";


const OrderPlaced = () => {

    return (
        <div>
        <Header/>
        <div className="ordercontainer">
            <div className="order">
                <div >
                    <h1 className="item1">Order Placed Successfully</h1>
                </div>
                <br></br>
                <br></br>
                <div className="item2">
                    Hurray!! Your order is confirmed <br></br>the order Id is #123456 save the order id for <br></br>further communication
                </div>
            </div>
            <br></br>
            <div className="Container2">
                <div className="row0">
                    <div className="item3">
                        Email us
                    </div>
                    <div className="item4">
                        Contact us
                    </div>
                    <div className="item5">
                        Address
                    </div>
                </div>

                <div className="row2">
                    <div className="item6">
                        admin@gmail.com
                    </div>
                    <div className="item6">
                        919874561230
                    </div>
                    <div className="item6">
                        25-a,Moh rao ka near govt school,Alwar
                    </div>
                </div>

            </div>
            <br></br>
            <Button variant="contained">Continue Shopping</Button>

        </div>

        </div>

    )
}

export default OrderPlaced