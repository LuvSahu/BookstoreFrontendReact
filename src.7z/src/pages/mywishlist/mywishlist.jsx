import React, { useEffect, useState } from "react";
import { getwishlist } from "../../services/bookservice";
import OrderSummery from "../ordersummery/ordersummery";
import './mywishlist.css'
import Box from '@mui/material/Box';
import Header from "../header/header";
import DeleteForeverIcon from '@mui/icons-material/DeleteForever';


const MyWishlist = (props) => {
    const [wishlist, setwishlist] = useState([])

    useEffect(() => {
        getwishlist().then((response) => {
            console.log(response)
            setwishlist(response.data.data)
        }).catch((response) => {
            console.log(response)
        })
    }, [])

    console.log(wishlist)

    return (
        <div>
            <Header />
            <Box className="container">
                <Box className="header00">
                    <h3>My Wishlist</h3>
                </Box>
            </Box>
            <div className="rowtwo1">
                <div className="Imgi">
                    <img src="/images/image 11.png" width="70px" />
                </div>
                <div className="item211">
                    {
                        wishlist.map(bookwish => {

                            <div>
                                <b>
                                    {/* Don't Make Me Think */}
                                {bookwish.bookName}  
                                </b>
                                <div className="dlicon">
                                    <DeleteForeverIcon />
                                </div>
                                <div className="row311">
                                    {/* by Steve Krug */}
                                    {bookwish.author}
                                </div>
                                <div className="row411">
                                    Rs. {bookwish.price}
                                    <span className="bookcost11">Rs {bookwish.discountprice}</span>

                                </div>

                            </div>
                        })
                    }


                </div>

            </div>
        </div>
    )
}

export default MyWishlist