import React, { useEffect, useState } from "react";
import './ordersummery.css'
import Button from '@mui/material/Button';
import { getorder } from "../../services/bookservice";


const OrderSummery = () => {

    const [order, setorder] = useState([])

    useEffect(() => {
        getorder().then((response) => {
            console.log(response)
            setorder(response.data.data)
        }).catch((response) => {
            console.log(response)
        })
    }, [])

    return (
        <div className="orderContainer">
            <div className="itemone">
                Order Summery
            </div>

            <div className="rowtwo">
                <div className="Imgi1">
                    <img src="/images/image 11.png" width="70px" />
                </div>
                <div className="item21">
                    {
                        order.map(bookorder => (
                            <div>

                                <b>
                                    {/* Don't Make Me Think */}
                                    {bookorder.bookName}

                                </b>
                                <div className="row31">
                                    {/* by Steve Krug */}
                                    {bookorder.author}
                                </div>
                                <div className="row41">
                                    Rs.{bookorder.totalPrice}
                                    <span className="bookcost1">Rs 2000</span>

                                </div>
                            </div>
                        ))
                    }


                </div>

                <div className="row12">
                    <Button id="btn-13" variant="contained"  >CHECKOUT</Button>
                </div>

            </div>

        </div>
    )
}

export default OrderSummery