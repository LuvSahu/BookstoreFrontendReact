import React, { useEffect, useState } from "react";
import { GetAllBooks } from "../../services/bookservice";
import BookDetails from "../bookdeatails/bookdetails";
import Books from "../books/books";
import Header from "../header/header";
import './dashboard.css'
const Dashboard = () => {

  const [allbooks, setAllbooks] = useState([])

  const [toggle, seTtoggle] = useState(false)

  const [bookdetails, setBookdetails] = useState({})


  const bookdetail = () => {
    seTtoggle(true)
  }

  const allbook = (data) =>  {
    console.log(data,"bookdetail")
    setBookdetails(data)
    seTtoggle(true)
    // console.log(bookdetails.bookname)
  }

  useEffect(() => {
    GetAllBooks()
      .then((response) => {
        console.log(response)
        setAllbooks(response.data.data)
      })
      .catch((error) => { console.log(error) })

  }, [])

  console.log(allbooks);





  return (
    <div>
      <Header />


      {
        toggle ? <BookDetails bookdetail = {bookdetail} bookdetails={bookdetails}/> :

          <div style={{ width: '78vw', height: '100vh', flexWrap: 'wrap', display: 'flex', gap: '1%', left: '10%', position: 'absolute', top: '17%' }}>
            {
              allbooks.map(book => (
                <div onClick={()=> allbook(book)}>
                <Books book={book} bookdetail={bookdetail} />
                </div>
              ))

            }

          </div>

        }



            </div>
            )
}

            export default Dashboard